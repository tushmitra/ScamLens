export type RuleAnalysis = {
  flags?: string[];
  reasons?: string[];
  flag_count?: number;
  disclaimer?: string;
  [key: string]: unknown;
};

export type UrlFinding = {
  url?: string;
  original_url?: string;
  flags?: string[];
  reasons?: string[];
  [key: string]: unknown;
};

export type UrlAnalysis = {
  urls?: UrlFinding[];
  [key: string]: unknown;
};

// The top-level fields below are confirmed in scamlens_api_v3.py.
// Nested rule/URL fields stay defensive until verified from a live response.
export type ScamLensResponse = {
  project: string;
  version: string;
  predicted_label?: number;
  category?: string;
  model_scam_score: number;
  model_scam_score_percent: number;
  model_score_is_calibrated: boolean;
  rule_analysis: RuleAnalysis;
  url_analysis: UrlAnalysis;
  overall_risk: string;
  reasons: string[];
  warning: string;
};

export type ApiErrorCode = "validation" | "http" | "network" | "response";

export class ScamLensApiError extends Error {
  code: ApiErrorCode;
  status?: number;

  constructor(message: string, code: ApiErrorCode, status?: number) {
    super(message);
    this.name = "ScamLensApiError";
    this.code = code;
    this.status = status;
  }
}
