import { useEffect, useRef, useState } from "react";
import { AnalysisResults } from "./components/AnalysisResults";
import { analyzeMessage } from "./services/scamLensApi";
import { ScamLensApiError, type ScamLensResponse } from "./types/api";

const SAMPLE_MESSAGE = "Your bank account will be blocked. Share your OTP now: https://bit.ly/example.";

function ShieldLogo({ small = false }: { small?: boolean }) {
  return (
    <span className={`shield-logo${small ? " shield-logo-small" : ""}`} aria-hidden="true">
      <svg viewBox="0 0 48 48" fill="none">
        <path d="M24 4.5 39 10v11.3c0 10.2-6.2 17.2-15 22.2C15.2 38.5 9 31.5 9 21.3V10L24 4.5Z" fill="url(#shieldFill)" stroke="rgba(255,255,255,.7)" strokeWidth="1.2" />
        <path d="m16.5 23.8 5 5 10.5-11" stroke="#F4FFF9" strokeWidth="3.3" strokeLinecap="round" strokeLinejoin="round" />
        <defs><linearGradient id="shieldFill" x1="9" y1="5" x2="39" y2="43" gradientUnits="userSpaceOnUse"><stop stopColor="#66F0C0"/><stop offset="1" stopColor="#2D8DFF"/></linearGradient></defs>
      </svg>
    </span>
  );
}

function ArrowIcon() {
  return <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11M10 5l5 5-5 5" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>;
}

function ScanIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m13-5v3a2 2 0 0 1-2 2h-3M6 12h12m-9-4v8m6-8v8" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>;
}

export default function App() {
  const [message, setMessage] = useState(SAMPLE_MESSAGE);
  const [result, setResult] = useState<ScamLensResponse | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const controllerRef = useRef<AbortController | null>(null);
  const requestIdRef = useRef(0);

  useEffect(() => () => controllerRef.current?.abort(), []);

  async function handleAnalyze() {
    controllerRef.current?.abort();
    const controller = new AbortController();
    controllerRef.current = controller;
    const requestId = ++requestIdRef.current;
    setResult(null);
    setError("");

    if (!message.trim()) {
      setError("Paste a message before starting the scan.");
      return;
    }
    if (message.trim().length > 10000) {
      setError("The message must be 10,000 characters or fewer.");
      return;
    }

    setLoading(true);
    try {
      const data = await analyzeMessage(message, controller.signal);
      if (requestId === requestIdRef.current) setResult(data);
    } catch (caught) {
      if (caught instanceof DOMException && caught.name === "AbortError") return;
      if (requestId === requestIdRef.current) {
        setError(caught instanceof ScamLensApiError || caught instanceof Error
          ? caught.message
          : "The scan could not be completed. Please try again.");
      }
    } finally {
      if (requestId === requestIdRef.current) setLoading(false);
    }
  }

  function updateMessage(value: string) {
    controllerRef.current?.abort();
    requestIdRef.current += 1;
    setLoading(false);
    setMessage(value);
    setResult(null);
    setError("");
  }

  function useSample() {
    updateMessage(SAMPLE_MESSAGE);
  }

  return (
    <div className="site-frame">
      <div className="ambient ambient-one" aria-hidden="true" />
      <div className="ambient ambient-two" aria-hidden="true" />
      <div className="ambient ambient-three" aria-hidden="true" />
      <div className="background-grid" aria-hidden="true" />

      <header className="topbar">
        <a className="brand" href="#top" aria-label="ScamLens home">
          <ShieldLogo />
          <span className="brand-wordmark">Scam<span>Lens</span><small>THINK BEFORE YOU CLICK</small></span>
        </a>
        <nav className="top-nav" aria-label="Main navigation">
          <a href="#scanner">Scanner</a>
          <a href="#how-it-works">How it works</a>
        </nav>
        <div className="topbar-status"><span className="live-dot" /> <span>Risk intelligence <b>prototype</b></span></div>
      </header>

      <main id="top" className="page-content">
        <section className="hero-section">
          <div className="hero-copy reveal-up">
            <div className="eyebrow-pill"><span className="eyebrow-sparkle">✳</span> YOUR DIGITAL INSTINCT, UPGRADED</div>
            <h1>Pause the scam.<br /><span>Protect your world.</span></h1>
            <p className="hero-description">Suspicious message? Strange link? Get a clearer view of the warning signs before you make your next move.</p>
            <a className="hero-cta" href="#scanner">Scan a message <ArrowIcon /></a>
            <div className="hero-proof"><div className="proof-avatars"><span>✓</span><span>↗</span><span>⌁</span></div><p><strong>Clarity over guesswork.</strong><br />Understand the signals, not just a score.</p></div>
          </div>

          <div className="hero-art reveal-up delay-one" aria-label="Decorative digital shield illustration">
            <div className="orbit orbit-outer" /><div className="orbit orbit-inner" />
            <div className="orbit-node node-top"><span>01</span></div><div className="orbit-node node-right"><span>02</span></div><div className="orbit-node node-bottom"><span>03</span></div>
            <div className="hero-shield-glow" />
            <div className="hero-shield"><ShieldLogo /></div>
            <div className="float-card float-card-top"><span className="mini-icon mint">⌁</span><span><b>Message signals</b><small>Language patterns</small></span><i>↗</i></div>
            <div className="float-card float-card-bottom"><span className="mini-icon blue">⌘</span><span><b>Link inspection</b><small>Static indicators</small></span><span className="tiny-pulse" /></div>
            <div className="art-caption"><span className="caption-line" /> SIGNALS. CONTEXT. A SAFER NEXT STEP.</div>
          </div>
        </section>

        <section className="scanner-layout" id="scanner">
          <div className="scanner-intro">
            <div className="section-index"><span>01</span><span className="index-line" /> MESSAGE SCANNER</div>
            <h2>Let’s take a<br /><em>closer look.</em></h2>
            <p>Paste the message exactly as you received it. ScamLens will request an analysis from your configured API and show the returned signals.</p>
            <div className="scanner-feature"><span className="feature-icon"><ScanIcon /></span><span><b>Built for transparency</b><small>See why a message may deserve caution.</small></span></div>
            <div className="scanner-feature"><span className="feature-icon feature-icon-blue">⌁</span><span><b>Links stay unopened</b><small>Static inspection only; no automatic browsing.</small></span></div>
          </div>

          <div className="scanner-card">
            <div className="card-topline"><div className="card-title-group"><span className="card-icon"><ScanIcon /></span><span><b>Scan a message</b><small>MESSAGE & URL CHECK</small></span></div><span className="secure-tag"><span className="tiny-pulse" /> READY</span></div>
            <div className="card-divider" />
            <div className="input-label-row"><label htmlFor="message-input">Message content</label><span className="input-type"><span /> TEXT INPUT</span></div>
            <div className="textarea-wrap"><span className="textarea-gutter">✳</span><textarea id="message-input" value={message} onChange={(event) => updateMessage(event.target.value)} maxLength={10000} rows={5} placeholder="Paste an SMS, email, or chat message..." /><div className="textarea-corner" /></div>
            <div className="input-meta"><span>{message.length.toLocaleString()} <span className="meta-muted">/ 10,000 characters</span></span><button type="button" className="text-button" onClick={() => updateMessage("")}>Clear text <span>×</span></button></div>
            <div className="sample-row"><span className="sample-label">TRY A SAMPLE</span><button type="button" className="sample-chip" onClick={useSample}>Bank alert <span>↗</span></button><span className="sample-caption">Prefilled for preview</span></div>
            <button type="button" className="primary-button" onClick={handleAnalyze} disabled={loading || !message.trim()}>
              {loading ? <><span className="button-spinner" /> Analyzing with ScamLens…</> : <><ScanIcon /> Analyze message <ArrowIcon /></>}
            </button>
            <div className="privacy-line"><svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M10 2.5 16 5v4.6c0 4.1-2.5 6.9-6 8.9-3.5-2-6-4.8-6-8.9V5l6-2.5Z" stroke="currentColor" strokeWidth="1.4"/><path d="m7.5 9.8 1.7 1.7 3.5-3.6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg><span>Your text is sent to your configured ScamLens API only when you scan.</span><span className="privacy-dot">•</span><span>Links aren’t opened.</span></div>
          </div>
        </section>

        {error && <section className="error-panel result-enter" role="alert"><span className="alert-mark">!</span><div><h3>We couldn’t complete the scan</h3><p>{error}</p><button type="button" className="secondary-button" onClick={handleAnalyze} disabled={loading}>Try again <ArrowIcon /></button></div></section>}
        {loading && <section className="status-panel result-enter" role="status" aria-live="polite"><span className="scan-radar"><i /></span><span><b>Checking the signals</b><small>Waiting for a response from the configured ScamLens API…</small></span><span className="loading-dots"><i /><i /><i /></span></section>}
        {!result && !loading && !error && <section className="empty-result result-enter"><div className="empty-visual"><div className="empty-ring ring-one" /><div className="empty-ring ring-two" /><span><ShieldLogo small /></span></div><div><div className="empty-status"><span className="status-dot" /> AWAITING FIRST SCAN</div><h3>Your insight starts here.</h3><p>Sample message has not been analyzed yet. Select <strong>Analyze message</strong> to request a real response from your configured API.</p></div><span className="empty-arrow">↘</span></section>}
        {result && <div className="result-enter"><AnalysisResults result={result} /></div>}

        <section className="how-section" id="how-it-works">
          <div className="section-index"><span>02</span><span className="index-line" /> A LITTLE MORE CLARITY</div>
          <div className="how-heading"><h2>Better informed.<br /><em>Never overconfident.</em></h2><p>ScamLens is designed to explain its signals, while being honest about what it cannot know.</p></div>
          <div className="how-grid">
            <article className="how-card"><span className="how-number">01</span><span className="how-icon mint-icon">✳</span><h3>Read the message</h3><p>Look for pressure, requests for sensitive information, and other patterns identified by the rules.</p><span className="card-decoration">↗</span></article>
            <article className="how-card"><span className="how-number">02</span><span className="how-icon blue-icon">⌁</span><h3>Inspect the link</h3><p>Review static URL indicators without automatically opening the submitted destination.</p><span className="card-decoration">↗</span></article>
            <article className="how-card"><span className="how-number">03</span><span className="how-icon violet-icon">◈</span><h3>Choose your next step</h3><p>Use the returned reasons as guidance. No warning detected does not mean a message is safe.</p><span className="card-decoration">↗</span></article>
          </div>
        </section>

        <aside className="safety-banner"><span className="safety-symbol">!</span><div><strong>Keep your secrets yours.</strong><p>Never share an OTP, PIN, password, or banking credential. Verify urgent account warnings through your bank’s official app or a trusted phone number.</p></div><ShieldLogo small /></aside>
        <footer className="app-footer"><a className="footer-brand" href="#top"><ShieldLogo small /> ScamLens</a><span>Experimental screening · Not proof of fraud or safety</span><a href="#top" className="back-top">BACK TO TOP ↑</a></footer>
      </main>
    </div>
  );
}
