import { ScamLensApiError, type ScamLensResponse } from "../types/api";

const API_BASE_URL = (
  import.meta.env.VITE_SCAMLENS_API_URL || "http://localhost:8000"
).replace(/\/+$/, "");

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every((item) => typeof item === "string");
}

function isScamLensResponse(value: unknown): value is ScamLensResponse {
  if (!isRecord(value)) return false;
  return (
    typeof value.project === "string" &&
    typeof value.version === "string" &&
    typeof value.overall_risk === "string" &&
    isStringArray(value.reasons) &&
    typeof value.warning === "string" &&
    typeof value.model_scam_score === "number" &&
    typeof value.model_scam_score_percent === "number" &&
    typeof value.model_score_is_calibrated === "boolean" &&
    isRecord(value.rule_analysis) &&
    isRecord(value.url_analysis)
  );
}

export async function analyzeMessage(
  message: string,
  signal?: AbortSignal,
): Promise<ScamLensResponse> {
  const cleanedMessage = message.trim();

  if (!cleanedMessage) {
    throw new ScamLensApiError("Enter a message before scanning.", "validation");
  }
  if (cleanedMessage.length > 10000) {
    throw new ScamLensApiError(
      "Messages must be 10,000 characters or fewer.",
      "validation",
    );
  }

  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}/check`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ message: cleanedMessage }),
      signal,
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") throw error;
    throw new ScamLensApiError(
      "Could not connect to ScamLens. Check that the API is running and try again.",
      "network",
    );
  }

  if (!response.ok) {
    let message = `ScamLens returned an error (${response.status}).`;
    try {
      const body: unknown = await response.json();
      if (isRecord(body) && typeof body.detail === "string") message = body.detail;
    } catch {
      // Retain the safe, generic HTTP error.
    }
    throw new ScamLensApiError(message, "http", response.status);
  }

  let data: unknown;
  try {
    data = await response.json();
  } catch {
    throw new ScamLensApiError("ScamLens returned invalid JSON.", "response");
  }

  if (!isScamLensResponse(data)) {
    throw new ScamLensApiError(
      "ScamLens returned an unexpected response shape. Check the API contract.",
      "response",
    );
  }

  return data;
}
