import type { ReactNode } from "react";
import type { ScamLensResponse, UrlFinding } from "../types/api";

function stringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
}

function labelForUrl(item: UrlFinding): string {
  if (typeof item.url === "string") return item.url;
  if (typeof item.original_url === "string") return item.original_url;
  return "URL finding";
}

export function AnalysisResults({ result }: { result: ScamLensResponse }) {
  const flags = stringArray(result.rule_analysis.flags);
  const ruleReasons = stringArray(result.rule_analysis.reasons);
  const urls = Array.isArray(result.url_analysis.urls) ? result.url_analysis.urls : [];

  return (
    <section className="results-panel" aria-live="polite" aria-labelledby="results-title">
      <div className="results-heading">
        <div>
          <p className="eyebrow">Response from configured API</p>
          <h2 id="results-title">Screening results</h2>
        </div>
        <span className="risk-badge">{result.overall_risk}</span>
      </div>
      <p className="result-warning">{result.warning}</p>

      <SignalSection title="Reasons">
        {result.reasons.length ? <ul>{result.reasons.map((reason, i) => <li key={`${i}-${reason}`}>{reason}</li>)}</ul> : <p>No reasons were returned.</p>}
      </SignalSection>

      <SignalSection title="Message rule indicators">
        {flags.length ? <>
          <p>{typeof result.rule_analysis.flag_count === "number" ? result.rule_analysis.flag_count : flags.length} indicator(s) returned.</p>
          <ul>{flags.map((flag) => <li key={flag}>{flag.replaceAll("_", " ")}</li>)}{ruleReasons.map((reason, i) => <li key={`rule-${i}`}>{reason}</li>)}</ul>
        </> : <p>No message rule flags were returned. This alone does not mean safe.</p>}
        {typeof result.rule_analysis.disclaimer === "string" && <small>{result.rule_analysis.disclaimer}</small>}
      </SignalSection>

      <SignalSection title="Static URL indicators">
        {urls.length ? urls.map((item, i) => {
          const itemFlags = stringArray(item.flags);
          const itemReasons = stringArray(item.reasons);
          return <article className="url-item" key={`${labelForUrl(item)}-${i}`}>
            <p className="url-text">{labelForUrl(item)}</p>
            {itemFlags.length > 0 && <p>Indicators: {itemFlags.map((flag) => flag.replaceAll("_", " ")).join(", ")}</p>}
            {itemReasons.length > 0 && <ul>{itemReasons.map((reason, j) => <li key={j}>{reason}</li>)}</ul>}
          </article>;
        }) : <p>No URL findings were returned. That does not establish that a message or link is safe.</p>}
      </SignalSection>

      <SignalSection title="Experimental model signal">
        <p>Model score: {result.model_scam_score_percent}%</p>
        <p>Calibration: {result.model_score_is_calibrated ? "Calibrated" : "Not calibrated — context only"}</p>
        <small>The model score is an experimental signal, not a verified probability of fraud.</small>
      </SignalSection>
    </section>
  );
}

function SignalSection({ title, children }: { title: string; children: ReactNode }) {
  return <section className="signal-section"><h3>{title}</h3>{children}</section>;
}
